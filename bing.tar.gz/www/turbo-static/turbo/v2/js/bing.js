if($("div").hasClass("login-main") == true || document.referrer.indexOf('login_web.html') != -1){
	$("body").css("transition","background 1.5s linear").css("background-image","url(/turbo-static/turbo/v2/img/bing.png?v="+Math.random()+")");
}else{
	 $("body").css("background-image","url(/turbo-static/turbo/v2/img/bing.png?v="+Math.random()+")");
}
var myDate = new Date(); 
$("#header div.logo a").attr("href","/turbo-static/turbo/v2/img/bing.png").attr("download","Bing-"+myDate.getFullYear()+(myDate.getMonth()+1)+myDate.getDate()+".png");