#!/bin/sh
# Copyright (C) 2016 evenS
pic_path="/tmp/bing.png"
pic_tmp_path="/tmp/bing.tmp"
bing_api_url="http://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1"
bing_api_url_spare0="http://tu.ihuan.me/api/bing/go"
bing_api_url_spare1="http://www.dujin.org/sys/bing/1920.php"
bing_json_path="/tmp/bing.json"
bing_pic_base_url_path="/tmp/bing_base.url"
bing_pic_url_pix="http://www.bing.com/"
bing_pic_url_Extension="_1920x1080.jpg"
version=0.2.1

cron(){
    get_picture;
    if [ -f "$pic_tmp_path" ]; then 
        if [ ! -f "$pic_path" ]; then
            mv -f $pic_tmp_path $pic_path
        else
            if [ `md5sum $pic_tmp_path | cut -d ' ' -f1` != `md5sum $pic_path | cut -d ' ' -f1` ]; then
                mv -f $pic_tmp_path $pic_path
            fi 
        fi
        rm -rf $pic_tmp_path
    fi
}

get_picture(){
    curl -m 5 -Lkso $bing_json_path  $bing_api_url  #官方api下载
    if [ ! -f "$bing_json_path" ]; then #官方api断言，失败为true
    echo "测试解析官方API失败"
    extra_get_pic;
    else
        lua /etc/BingBackgroud/json.lua
        curl -m 10 -Lkso $pic_tmp_path  $bing_pic_url_pix`cat $bing_pic_base_url_path`$bing_pic_url_Extension
        if [ ! -f "$pic_tmp_path" ]; then
            rm -rf $bing_json_path
            rm -rf $pic_tmp_path
            rm -rf $bing_pic_base_url_path
            extra_get_pic;
        else
            if [[ "$(hexdump -s $((`ls -l $pic_tmp_path | awk '{print $5}'`-2)) $pic_tmp_path | awk 'NR==1{print $2}')" != "d9ff" ]] ; then
                curl -m 30 -Lkso $pic_tmp_path $bing_pic_url_pix`cat $bing_pic_base_url_path`$bing_pic_url_Extension
                if [ ! -f "$pic_tmp_path" ]; then
                    hwf-at 300 /etc/BingBackgroud/get_bing_cron.sh cron
                    echo "测试解析官方API成功，下载失败！5分钟后重试"
                fi
                
            fi
            echo "测试解析官方API成功，下载成功！"
        fi
    fi

    rm -rf $bing_json_path
    rm -rf $bing_pic_base_url_path
    
}

path_js(){
	if [  `grep -c "bing.js"  /usr/lib/lua/luci/view/admin_web/footer.htm` = 0 ]; then
		echo "<script type=\"text/javascript\" src=\"<%=resource%>/v2/js/bing.js?v=$version\"></script>" >> /usr/lib/lua/luci/view/admin_web/footer.htm
	fi
	if [  `grep -c "bing.js"  /www/turbo-static/turbo/v2/js/admin_web/login.js` = 0 ]; then
		echo "$.getScript(\"/turbo-static/turbo/v2/js/bing.js?v=$version\");" >> /www/turbo-static/turbo/v2/js/admin_web/login.js
	fi
}

restore_js(){
    sed -i "\#<script type=\"text/javascript\" src=\"<%=resource%>/v2/js/bing.js?v=$version\"></script>#d" /usr/lib/lua/luci/view/admin_web/footer.htm
    sed -i "\#$.getScript(\"/turbo-static/turbo/v2/js/bing.js?v=$version\");#d" /www/turbo-static/turbo/v2/js/admin_web/login.js
}

set_crontabs() {
	sed -i '\/etc\/BingBackgroud\/get_bing_cron.sh cron/d' /etc/crontabs/root 
	echo "10 0 * * * sh /etc/BingBackgroud/get_bing_cron.sh cron" >>/etc/crontabs/root
	touch /etc/crontabs/cron.update
	/etc/init.d/cron restart
}

del_crontabs() {
	sed -i '\/etc\/BingBackgroud\/get_bing_cron.sh cron/d' /etc/crontabs/root 
	touch /etc/crontabs/cron.update
	/etc/init.d/cron restart	
}

extra_get_pic(){
    curl -m 10 -Lkso $pic_tmp_path $bing_api_url_spare0 #尝试使用第三方api下载
    if [ ! -f "$pic_tmp_path" ]; then
        curl -m 10 -Lkso $pic_tmp_path $bing_api_url_spare1
    fi
    if [ ! -f "$pic_tmp_path" ]; then #第三方api下载状态断言 失败为true
        rm -rf $bing_json_path
        rm -rf $pic_tmp_path
        rm -rf $bing_pic_base_url_path
        echo "<User-Echo>测试解析官方API失败，测试第三方API失败，下载失败！5分钟之后再试。"
        hwf-at 300 /etc/BingBackgroud/get_bing_cron.sh cron      
        return  #下载失败退出
    else
        if [[ "$(hexdump -s $((`ls -l $pic_tmp_path | awk '{print $5}'`-2)) $pic_tmp_path | awk 'NR==1{print $2}')" != "d9ff" ]] ; then
            curl -m 30 -Lkso $pic_tmp_path $bing_api_url_spare0
            if [ ! -f "$pic_tmp_path" ]; then
                curl -m 30 -Lkso $pic_tmp_path $bing_api_url_spare1
                if [ ! -f "$pic_tmp_path" ]; then
                    hwf-at 300 /etc/BingBackgroud/get_bing_cron.sh cron
                    echo "测试第三方API成功，下载失败！5分钟后重试"
                fi
            fi
        fi
        echo "测试第三方API成功，下载成功！"        
    fi 
}

case "$1" in
    "cron")
        cron;
        exit 0;
        ;;
    "install")
        path_js;
        set_crontabs;
        exit 0;
        ;;
    "uninstall")
        restore_js;
        del_crontabs;
        exit 0;
        ;;                
esac        